const { HttpError } = require("../utils/http");

function parseCookieHeader(cookieHeader = "") {
  return cookieHeader.split(";").reduce((accumulator, pair) => {
    const [rawKey, ...valueParts] = pair.split("=");
    if (!rawKey) {
      return accumulator;
    }

    accumulator[rawKey.trim()] = decodeURIComponent(valueParts.join("=").trim());
    return accumulator;
  }, {});
}

function createAuthMiddleware(config, authService) {
  function attachUser(req, _res, next) {
    const cookies = parseCookieHeader(req.headers.cookie || "");
    const token = cookies[config.sessionCookieName];
    const sessionState = authService.getUserByToken(token);
    req.sessionToken = token || null;
    req.auth = sessionState;
    req.user = sessionState ? sessionState.user : null;
    next();
  }

  function requireAuth(req, _res, next) {
    if (!req.user) {
      return next(new HttpError(401, "Debe iniciar sesión para continuar."));
    }
    return next();
  }

  function requireRoles(...roles) {
    return (req, _res, next) => {
      if (!req.user) {
        return next(new HttpError(401, "Debe iniciar sesión para continuar."));
      }

      if (!roles.includes(req.user.role)) {
        return next(new HttpError(403, "No tiene permisos para realizar esta accion."));
      }

      return next();
    };
  }

  return {
    attachUser,
    requireAuth,
    requireRoles
  };
}

module.exports = {
  createAuthMiddleware
};
