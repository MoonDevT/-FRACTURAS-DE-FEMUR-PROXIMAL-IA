﻿const fs = require("fs");
const path = require("path");
const { ensureDirectory, ensureJsonFile, writeJson } = require("./fileStore");
const { createPasswordHash } = require("../utils/crypto");

function bootstrapStorage(config) {
  ensureDirectory(config.localStoragePath);
  ensureDirectory(config.analysisHistoryPath);
  ensureDirectory(config.auditLogPath);
  ensureDirectory(config.uploadsPath);
  ensureDirectory(config.resultsPath);

  ensureJsonFile(config.usersFilePath, []);
  ensureJsonFile(config.sessionsFilePath, []);
  ensureJsonFile(config.historyFilePath, []);

  const existingUsers = JSON.parse(fs.readFileSync(config.usersFilePath, "utf8") || "[]");
  if (!Array.isArray(existingUsers) || existingUsers.length === 0) {
    const seededUsers = config.defaultUsers.map((user, index) => ({
      id: `user_${index + 1}`,
      username: user.username,
      passwordHash: createPasswordHash(user.password),
      role: user.role,
      displayName: user.displayName,
      active: true,
      createdAt: new Date().toISOString()
    }));
    writeJson(config.usersFilePath, seededUsers);
  }

  if (!fs.existsSync(config.modelMetadataPath)) {
    ensureDirectory(path.dirname(config.modelMetadataPath));
    fs.writeFileSync(
      config.modelMetadataPath,
      JSON.stringify(
        {
          modelFamily: config.modelFamily,
          modelVersion: config.modelVersion,
          modelPath: config.modelPath,
          inferenceAdapter: "yolo",
          createdAt: new Date().toISOString(),
          notes: "Metadata local del modelo para inferencia YOLO en entorno local."
        },
        null,
        2
      )
    );
  }
}

module.exports = {
  bootstrapStorage
};
