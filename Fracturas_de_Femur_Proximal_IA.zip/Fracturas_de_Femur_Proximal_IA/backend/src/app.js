const path = require("path");
const express = require("express");
const multer = require("multer");
const { createConfig } = require("./config/env");
const { bootstrapStorage } = require("./storage/bootstrap");
const { createAuditService } = require("./services/auditService");
const { createAuthService } = require("./services/authService");
const { createInferenceService } = require("./services/inference");
const { createAnalysisService } = require("./services/analysisService");
const { createAuthMiddleware } = require("./middleware/auth");
const { HttpError, asyncRoute, sendError } = require("./utils/http");

function createApp(overrides = {}) {
  const config = createConfig(overrides);
  bootstrapStorage(config);

  const auditService = createAuditService(config);
  const authService = createAuthService(config, auditService);
  const inferenceService = createInferenceService(config);
  const analysisService = createAnalysisService(config, auditService, inferenceService);
  const authMiddleware = createAuthMiddleware(config, authService);

  const app = express();
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: config.maxUploadMb * 1024 * 1024
    }
  });

  app.disable("x-powered-by");
  app.use(express.json());
  app.use(express.urlencoded({ extended: false }));
  app.use(authMiddleware.attachUser);

  app.get("/api/health", (_req, res) => {
    res.json({
      ok: true,
      appName: config.appName,
      timestamp: new Date().toISOString()
    });
  });

  app.get("/api/model", (_req, res) => {
    res.json({
      model: inferenceService.getModelInfo()
    });
  });

  app.post(
    "/api/auth/login",
    asyncRoute(async (req, res) => {
      const { username, password } = req.body || {};
      if (!username || !password) {
        throw new HttpError(400, "Debe proporcionar usuario y contraseña.");
      }

      const { session, user } = authService.login(username, password, {
        ip: req.ip,
        userAgent: req.headers["user-agent"]
      });

      res.setHeader(
        "Set-Cookie",
        `${config.sessionCookieName}=${encodeURIComponent(session.token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${config.sessionTimeoutMinutes * 60}`
      );

      res.json({
        user,
        expiresAt: session.expiresAt
      });
    })
  );

  app.post(
    "/api/auth/logout",
    authMiddleware.requireAuth,
    asyncRoute(async (req, res) => {
      authService.logout(req.sessionToken, req.user.username);
      res.setHeader(
        "Set-Cookie",
        `${config.sessionCookieName}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0`
      );
      res.json({ ok: true });
    })
  );

  app.get(
    "/api/auth/me",
    asyncRoute(async (req, res) => {
      if (!req.user) {
        throw new HttpError(401, "No hay una sesión activa.");
      }

      res.json({
        user: req.user
      });
    })
  );

  app.post(
    "/api/analysis",
    authMiddleware.requireAuth,
    upload.single("image"),
    asyncRoute(async (req, res) => {
      const analysis = analysisService.performAnalysis(req.file, req.user, {
        ip: req.ip
      });

      res.json({
        analysis
      });
    })
  );

  app.get(
    "/api/analysis/history",
    authMiddleware.requireAuth,
    asyncRoute(async (req, res) => {
      const limit = Number.parseInt(req.query.limit, 10) || 25;
      res.json({
        items: analysisService.listHistory(req.user, limit)
      });
    })
  );

  app.get(
    "/api/admin/audit",
    authMiddleware.requireRoles("admin"),
    asyncRoute(async (req, res) => {
      const limit = Number.parseInt(req.query.limit, 10) || 100;
      res.json({
        items: auditService.list(limit)
      });
    })
  );

  app.use(express.static(config.frontendPath));

  app.get("*", (_req, res) => {
    res.sendFile(path.join(config.frontendPath, "index.html"));
  });

  app.use((error, _req, res, _next) => {
    if (error instanceof multer.MulterError && error.code === "LIMIT_FILE_SIZE") {
      return sendError(
        res,
        new HttpError(400, "El archivo excede el tamano maximo permitido.")
      );
    }

    return sendError(res, error);
  });

  return {
    app,
    config,
    services: {
      analysisService,
      auditService,
      authService,
      inferenceService
    }
  };
}

module.exports = {
  createApp
};
