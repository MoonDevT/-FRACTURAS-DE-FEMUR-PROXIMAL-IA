const path = require("path");
const { HttpError } = require("./http");

function sanitizeFileName(fileName) {
  const extension = path.extname(fileName || "").toLowerCase();
  const nameWithoutExt = path
    .basename(fileName || "imagen", extension)
    .replace(/[^a-zA-Z0-9_-]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "");

  return `${nameWithoutExt || "imagen"}${extension}`;
}

function getExtension(fileName) {
  return path.extname(fileName || "").toLowerCase();
}

function detectImageType(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 8) {
    return null;
  }

  const isPng =
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47 &&
    buffer[4] === 0x0d &&
    buffer[5] === 0x0a &&
    buffer[6] === 0x1a &&
    buffer[7] === 0x0a;

  if (isPng) {
    return { mimeType: "image/png", extension: ".png" };
  }

  const isJpeg =
    buffer[0] === 0xff &&
    buffer[1] === 0xd8 &&
    buffer[2] === 0xff;

  if (isJpeg) {
    return { mimeType: "image/jpeg", extension: ".jpg" };
  }

  return null;
}

function ensureAllowedExtension(fileName, allowedExtensions) {
  const extension = getExtension(fileName);
  if (!allowedExtensions.has(extension)) {
    throw new HttpError(400, "El formato del archivo no esta permitido.");
  }
  return extension;
}

module.exports = {
  detectImageType,
  ensureAllowedExtension,
  getExtension,
  sanitizeFileName
};
