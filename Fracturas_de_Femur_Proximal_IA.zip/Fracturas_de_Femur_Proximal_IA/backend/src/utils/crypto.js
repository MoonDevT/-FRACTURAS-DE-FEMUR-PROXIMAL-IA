const crypto = require("crypto");

function createPasswordHash(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const derivedKey = crypto
    .scryptSync(password, salt, 64)
    .toString("hex");
  return `${salt}:${derivedKey}`;
}

function verifyPassword(password, storedHash) {
  const [salt, savedKey] = String(storedHash || "").split(":");
  if (!salt || !savedKey) {
    return false;
  }

  const candidateKey = crypto
    .scryptSync(password, salt, 64)
    .toString("hex");

  return crypto.timingSafeEqual(
    Buffer.from(savedKey, "hex"),
    Buffer.from(candidateKey, "hex")
  );
}

function createToken(size = 32) {
  return crypto.randomBytes(size).toString("hex");
}

function createHash(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

module.exports = {
  createHash,
  createPasswordHash,
  createToken,
  verifyPassword
};
