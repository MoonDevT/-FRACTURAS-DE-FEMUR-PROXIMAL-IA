﻿class HttpError extends Error {
  constructor(status, message, details = null) {
    super(message);
    this.name = "HttpError";
    this.status = status;
    this.details = details;
  }
}

function asyncRoute(handler) {
  return async (req, res, next) => {
    try {
      await handler(req, res, next);
    } catch (error) {
      next(error);
    }
  };
}

function sendError(res, error) {
  const status = error.status || 500;
  const message =
    status >= 500 ? "Ocurrio un error interno durante la operación." : error.message;
  const payload = { error: { message } };

  if (error.details && status < 500) {
    payload.error.details = error.details;
  }

  res.status(status).json(payload);
}

module.exports = {
  HttpError,
  asyncRoute,
  sendError
};
