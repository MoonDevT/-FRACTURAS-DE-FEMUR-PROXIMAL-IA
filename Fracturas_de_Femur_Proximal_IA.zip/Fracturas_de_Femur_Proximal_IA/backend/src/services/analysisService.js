﻿const fs = require("fs");
const path = require("path");
const { imageSize } = require("image-size");
const { readJson, writeJson } = require("../storage/fileStore");
const { createHash } = require("../utils/crypto");
const {
  detectImageType,
  ensureAllowedExtension,
  sanitizeFileName
} = require("../utils/files");
const { HttpError } = require("../utils/http");

function createAnalysisService(config, auditService, inferenceService) {
  function storeUpload(buffer, fileName, analysisId) {
    if (!config.keepUploadedFiles) {
      return null;
    }

    const extension = path.extname(fileName);
    const storedFileName = `${analysisId}${extension}`;
    const targetPath = path.join(config.uploadsPath, storedFileName);
    fs.writeFileSync(targetPath, buffer);
    return storedFileName;
  }

  function readHistory() {
    return readJson(config.historyFilePath, []);
  }

  function writeHistory(entries) {
    writeJson(config.historyFilePath, entries);
  }

  function summarizeResult(detections) {
    if (detections.length === 0) {
      return {
        overallStatus: "no_findings",
        affectedSides: [],
        interpretation:
          "No se identificó una fractura visible con el adaptador configurado. El resultado requiere validación por personal médico."
      };
    }

    const affectedSides = [...new Set(detections.map((detection) => detection.side))];
    return {
      overallStatus: "findings_detected",
      affectedSides,
      interpretation:
        "Se identificaron hallazgos sospechosos compatibles con fractura de fémur proximal. Este resultado es de apoyo diagnóstico y requiere validación por personal médico."
    };
  }

  function performAnalysis(file, user, requestMeta = {}) {
    if (!file || !Buffer.isBuffer(file.buffer) || file.buffer.length === 0) {
      throw new HttpError(400, "Debe proporcionar una imagen válida para el análisis.");
    }

    ensureAllowedExtension(file.originalname, config.allowedExtensions);

    const detectedType = detectImageType(file.buffer);
    if (!detectedType) {
      throw new HttpError(400, "El archivo no corresponde a una imagen JPG o PNG válida.");
    }

    const dimensions = imageSize(file.buffer);
    if (!dimensions || !dimensions.width || !dimensions.height) {
      throw new HttpError(400, "No fue posible interpretar las dimensiones de la imagen.");
    }

    const analysisId = `analysis_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`;
    const sanitizedName = sanitizeFileName(file.originalname);
    const fingerprint = createHash(file.buffer).slice(0, 16);
    const inferenceResult = inferenceService.analyze({
      buffer: file.buffer,
      originalName: sanitizedName,
      mimeType: detectedType.mimeType,
      dimensions,
      fingerprint
    });

    const summary = summarizeResult(inferenceResult.detections);
    const storedFileName = storeUpload(file.buffer, sanitizedName, analysisId);
    const historyEntry = {
      id: analysisId,
      createdAt: new Date().toISOString(),
      actor: {
        id: user.id,
        username: user.username,
        role: user.role
      },
      file: {
        originalName: sanitizedName,
        mimeType: detectedType.mimeType,
        width: dimensions.width,
        height: dimensions.height,
        sizeBytes: file.buffer.length,
        fingerprint,
        storedFileName
      },
      model: inferenceService.getModelInfo(),
      detections: inferenceResult.detections,
      ...summary
    };

    const history = readHistory();
    history.unshift(historyEntry);
    writeHistory(history.slice(0, 500));

    auditService.log("analysis.created", user.username, {
      analysisId,
      overallStatus: summary.overallStatus,
      affectedSides: summary.affectedSides,
      fileName: sanitizedName,
      ip: requestMeta.ip || "unknown"
    });

    return historyEntry;
  }

  function listHistory(user, limit = 50) {
    const history = readHistory();

    if (user.role === "admin" || user.role === "specialist") {
      return history.slice(0, limit);
    }

    return history
      .filter((entry) => entry.actor.id === user.id)
      .slice(0, limit);
  }

  return {
    listHistory,
    performAnalysis
  };
}

module.exports = {
  createAnalysisService
};
