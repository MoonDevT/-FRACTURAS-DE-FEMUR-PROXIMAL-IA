﻿const { readJson, writeJson } = require("../storage/fileStore");
const { createHash, createToken, verifyPassword } = require("../utils/crypto");
const { HttpError } = require("../utils/http");

const ROLE_LABELS = {
  admin: "Administrador",
  physician: "Médico General",
  specialist: "Radiologo",
  operator: "Técnico Operador"
};

function sanitizeUser(user) {
  return {
    id: user.id,
    username: user.username,
    role: user.role,
    roleLabel: ROLE_LABELS[user.role] || user.role,
    displayName: user.displayName,
    active: user.active
  };
}

function createAuthService(config, auditService) {
  function readUsers() {
    return readJson(config.usersFilePath, []);
  }

  function readSessions() {
    return readJson(config.sessionsFilePath, []);
  }

  function writeSessions(sessions) {
    writeJson(config.sessionsFilePath, sessions);
  }

  function pruneExpiredSessions() {
    const now = Date.now();
    const activeSessions = readSessions().filter(
      (session) => new Date(session.expiresAt).getTime() > now
    );
    writeSessions(activeSessions);
    return activeSessions;
  }

  function createSession(user, requestMeta = {}) {
    const token = createToken();
    const tokenHash = createHash(token);
    const now = new Date();
    const expiresAt = new Date(
      now.getTime() + config.sessionTimeoutMinutes * 60 * 1000
    ).toISOString();

    const sessions = pruneExpiredSessions();
    sessions.push({
      id: `session_${now.getTime()}_${Math.random().toString(16).slice(2, 8)}`,
      userId: user.id,
      tokenHash,
      createdAt: now.toISOString(),
      expiresAt,
      ip: requestMeta.ip || "unknown",
      userAgent: requestMeta.userAgent || "unknown"
    });
    writeSessions(sessions);

    return { token, expiresAt };
  }

  function login(username, password, requestMeta = {}) {
    const normalizedUsername = String(username || "").trim().toLowerCase();
    const user = readUsers().find(
      (candidate) => candidate.username.toLowerCase() === normalizedUsername && candidate.active
    );

    if (!user || !verifyPassword(password, user.passwordHash)) {
      auditService.log("auth.login_failed", normalizedUsername || "unknown", {
        ip: requestMeta.ip || "unknown"
      });
      throw new HttpError(401, "Credenciales invalidas.");
    }

    const session = createSession(user, requestMeta);
    auditService.log("auth.login_success", user.username, {
      role: user.role,
      ip: requestMeta.ip || "unknown"
    });

    return {
      session,
      user: sanitizeUser(user)
    };
  }

  function getUserByToken(token) {
    if (!token) {
      return null;
    }

    const tokenHash = createHash(token);
    const activeSessions = pruneExpiredSessions();
    const session = activeSessions.find((candidate) => candidate.tokenHash === tokenHash);
    if (!session) {
      return null;
    }

    const user = readUsers().find((candidate) => candidate.id === session.userId && candidate.active);
    if (!user) {
      return null;
    }

    return {
      session,
      user: sanitizeUser(user)
    };
  }

  function logout(token, actor = "unknown") {
    if (!token) {
      return;
    }

    const tokenHash = createHash(token);
    const sessions = readSessions();
    const filteredSessions = sessions.filter((candidate) => candidate.tokenHash !== tokenHash);
    writeSessions(filteredSessions);
    auditService.log("auth.logout", actor, {});
  }

  return {
    getUserByToken,
    login,
    logout,
    sanitizeUser
  };
}

module.exports = {
  createAuthService,
  ROLE_LABELS
};
