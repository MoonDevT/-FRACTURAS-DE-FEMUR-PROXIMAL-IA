﻿const { HttpError } = require("../../utils/http");
const { createYoloAdapter } = require("./adapters/yoloAdapter");

function createInferenceService(config) {
  const activeAdapter = createYoloAdapter(config);

  if (!activeAdapter || typeof activeAdapter.analyze !== "function") {
    throw new HttpError(500, "No fue posible inicializar el adaptador YOLO local.");
  }

  function analyze(payload) {
    return activeAdapter.analyze(payload);
  }

  function getModelInfo() {
    return {
      adapter: "yolo",
      modelFamily: config.modelFamily,
      modelVersion: config.modelVersion,
      modelPath: config.modelPath,
      confidenceThreshold: config.confidenceThreshold,
      mode: "Inferencia local"
    };
  }

  return {
    analyze,
    getModelInfo
  };
}

module.exports = {
  createInferenceService
};
