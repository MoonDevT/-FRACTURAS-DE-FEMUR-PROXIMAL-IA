const { appendNdjson, readNdjson } = require("../storage/fileStore");

function createAuditService(config) {
  function log(eventType, actor, details = {}) {
    appendNdjson(config.auditFilePath, {
      id: `audit_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`,
      timestamp: new Date().toISOString(),
      eventType,
      actor,
      details
    });
  }

  function list(limit = 100) {
    return readNdjson(config.auditFilePath)
      .reverse()
      .slice(0, limit);
  }

  return {
    list,
    log
  };
}

module.exports = {
  createAuditService
};
