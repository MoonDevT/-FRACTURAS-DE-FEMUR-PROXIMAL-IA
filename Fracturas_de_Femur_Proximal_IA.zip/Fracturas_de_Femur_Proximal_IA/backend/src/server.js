const { createApp } = require("./app");

const { app, config } = createApp();

app.listen(config.backendPort, config.backendHost, () => {
  console.log(
    `${config.appName} escuchando en http://${config.backendHost}:${config.backendPort}`
  );
});
