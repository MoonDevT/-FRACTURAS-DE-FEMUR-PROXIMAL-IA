﻿const path = require("path");
const dotenv = require("dotenv");

let dotenvLoaded = false;

function loadDotenvOnce() {
  if (!dotenvLoaded) {
    dotenv.config();
    dotenvLoaded = true;
  }
}

function resolveProjectPath(...segments) {
  return path.resolve(process.cwd(), ...segments);
}

function parseInteger(value, fallbackValue) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) ? parsed : fallbackValue;
}

function parseFloatValue(value, fallbackValue) {
  const parsed = Number.parseFloat(value);
  return Number.isFinite(parsed) ? parsed : fallbackValue;
}

function parseBoolean(value, fallbackValue) {
  if (value === undefined) {
    return fallbackValue;
  }

  return ["1", "true", "yes", "on"].includes(String(value).toLowerCase());
}

function createConfig(overrides = {}) {
  loadDotenvOnce();

  const appEnv = process.env.APP_ENV || "development";
  const localStoragePath = resolveProjectPath(
    process.env.LOCAL_STORAGE_PATH || "data/local_storage"
  );
  const analysisHistoryPath = resolveProjectPath(
    process.env.ANALYSIS_HISTORY_PATH || "data/local_storage/analysis_history"
  );
  const auditLogPath = resolveProjectPath(
    process.env.AUDIT_LOG_PATH || "data/local_storage/audit"
  );

  const baseConfig = {
    appEnv,
    appName: process.env.APP_NAME || "FemurIA Local",
    backendHost: process.env.BACKEND_HOST || "127.0.0.1",
    backendPort: parseInteger(process.env.BACKEND_PORT, 8000),
    frontendPath: resolveProjectPath("frontend/app"),
    localStoragePath,
    analysisHistoryPath,
    auditLogPath,
    uploadsPath: path.join(localStoragePath, "uploads"),
    resultsPath: path.join(localStoragePath, "results"),
    usersFilePath: path.join(localStoragePath, "users.json"),
    sessionsFilePath: path.join(localStoragePath, "sessions.json"),
    historyFilePath: path.join(analysisHistoryPath, "history.json"),
    auditFilePath: path.join(auditLogPath, "audit.ndjson"),
    modelPath: resolveProjectPath(process.env.MODEL_PATH || "models/exports/best.pt"),
    modelMetadataPath: resolveProjectPath(
      process.env.MODEL_METADATA_PATH || "models/exports/model-metadata.json"
    ),
    modelVersion: process.env.MODEL_VERSION || "0.3.0",
    modelFamily: process.env.MODEL_FAMILY || "YOLOv8",
    confidenceThreshold: parseFloatValue(process.env.CONFIDENCE_THRESHOLD, 0.25),
    sessionSecret: process.env.SESSION_SECRET || "change_this_local_secret",
    sessionTimeoutMinutes: parseInteger(process.env.SESSION_TIMEOUT_MINUTES, 60),
    sessionCookieName: process.env.SESSION_COOKIE_NAME || "prox_femur_session",
    maxUploadMb: parseInteger(process.env.MAX_UPLOAD_MB, 10),
    keepUploadedFiles: parseBoolean(process.env.KEEP_UPLOADED_FILES, true),
    allowedExtensions: new Set([".jpg", ".jpeg", ".png"]),
    defaultUsers: [
      {
        username: process.env.DEFAULT_ADMIN_USER || "admin",
        password: process.env.DEFAULT_ADMIN_PASSWORD || "admin1234",
        role: "admin",
        displayName: "Administrador Local"
      },
      {
        username: process.env.DEFAULT_PHYSICIAN_USER || "medico",
        password: process.env.DEFAULT_PHYSICIAN_PASSWORD || "medico1234",
        role: "physician",
        displayName: "Médico General"
      },
      {
        username: process.env.DEFAULT_SPECIALIST_USER || "radiologo",
        password: process.env.DEFAULT_SPECIALIST_PASSWORD || "radiologo1234",
        role: "specialist",
        displayName: "Radiologo"
      },
      {
        username: process.env.DEFAULT_OPERATOR_USER || "tecnico",
        password: process.env.DEFAULT_OPERATOR_PASSWORD || "tecnico1234",
        role: "operator",
        displayName: "Técnico Operador"
      }
    ]
  };

  return {
    ...baseConfig,
    ...overrides
  };
}

module.exports = {
  createConfig
};
