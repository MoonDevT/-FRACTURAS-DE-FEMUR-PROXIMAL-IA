﻿const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { createApp } = require("../backend/src/app");

function createTinyPngBuffer() {
  return Buffer.from(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9VE0suoAAAAASUVORK5CYII=",
    "base64"
  );
}

async function createTestServer() {
  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), "femuria-test-"));
  const { app } = createApp({
    localStoragePath: path.join(tempRoot, "storage"),
    analysisHistoryPath: path.join(tempRoot, "storage", "analysis_history"),
    auditLogPath: path.join(tempRoot, "storage", "audit"),
    uploadsPath: path.join(tempRoot, "storage", "uploads"),
    resultsPath: path.join(tempRoot, "storage", "results"),
    usersFilePath: path.join(tempRoot, "storage", "users.json"),
    sessionsFilePath: path.join(tempRoot, "storage", "sessions.json"),
    historyFilePath: path.join(tempRoot, "storage", "analysis_history", "history.json"),
    auditFilePath: path.join(tempRoot, "storage", "audit", "audit.ndjson"),
    modelMetadataPath: path.join(tempRoot, "model-metadata.json"),
    frontendPath: path.resolve(process.cwd(), "frontend/app")
  });

  const server = await new Promise((resolve) => {
    const listeningServer = app.listen(0, "127.0.0.1", () => resolve(listeningServer));
  });

  const address = server.address();
  const baseUrl = `http://${address.address}:${address.port}`;

  return {
    baseUrl,
    close: () =>
      new Promise((resolve, reject) => {
        server.close((error) => {
          if (error) {
            reject(error);
            return;
          }
          fs.rmSync(tempRoot, { recursive: true, force: true });
          resolve();
        });
      })
  };
}

test("flujo completo de autenticacion, análisis, historial y auditoría", async () => {
  const runtime = await createTestServer();

  try {
    const loginResponse = await fetch(`${runtime.baseUrl}/api/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        username: "admin",
        password: "admin1234"
      })
    });
    assert.equal(loginResponse.status, 200);
    const cookie = loginResponse.headers.get("set-cookie").split(";")[0];

    const meResponse = await fetch(`${runtime.baseUrl}/api/auth/me`, {
      headers: { cookie }
    });
    const mePayload = await meResponse.json();
    assert.equal(mePayload.user.username, "admin");
    assert.equal(mePayload.user.role, "admin");

    const form = new FormData();
    form.append(
      "image",
      new Blob([createTinyPngBuffer()], { type: "image/png" }),
      "fracture_left.png"
    );

    const analysisResponse = await fetch(`${runtime.baseUrl}/api/analysis`, {
      method: "POST",
      headers: { cookie },
      body: form
    });
    assert.equal(analysisResponse.status, 200);
    const analysisPayload = await analysisResponse.json();
    assert.equal(analysisPayload.analysis.overallStatus, "findings_detected");
    assert.equal(analysisPayload.analysis.affectedSides[0], "left");
    assert.equal(analysisPayload.analysis.detections.length, 1);

    const historyResponse = await fetch(`${runtime.baseUrl}/api/analysis/history`, {
      headers: { cookie }
    });
    const historyPayload = await historyResponse.json();
    assert.equal(historyPayload.items.length, 1);
    assert.equal(historyPayload.items[0].file.originalName, "fracture_left.png");

    const auditResponse = await fetch(`${runtime.baseUrl}/api/admin/audit`, {
      headers: { cookie }
    });
    const auditPayload = await auditResponse.json();
    assert.ok(auditPayload.items.length >= 2);
    assert.ok(
      auditPayload.items.some((entry) => entry.eventType === "analysis.created")
    );
  } finally {
    await runtime.close();
  }
});

test("rechaza archivos invalidos y protege la bitácora administrativa", async () => {
  const runtime = await createTestServer();

  try {
    const loginResponse = await fetch(`${runtime.baseUrl}/api/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        username: "medico",
        password: "medico1234"
      })
    });
    const cookie = loginResponse.headers.get("set-cookie").split(";")[0];

    const invalidForm = new FormData();
    invalidForm.append(
      "image",
      new Blob([Buffer.from("archivo invalido")], { type: "text/plain" }),
      "nota.txt"
    );

    const invalidUploadResponse = await fetch(`${runtime.baseUrl}/api/analysis`, {
      method: "POST",
      headers: { cookie },
      body: invalidForm
    });
    assert.equal(invalidUploadResponse.status, 400);

    const auditResponse = await fetch(`${runtime.baseUrl}/api/admin/audit`, {
      headers: { cookie }
    });
    assert.equal(auditResponse.status, 403);
  } finally {
    await runtime.close();
  }
});
