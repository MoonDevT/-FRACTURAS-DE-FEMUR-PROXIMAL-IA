﻿from __future__ import annotations

import base64
import tempfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from backend_py.app.config import Settings
from backend_py.app.main import create_app
from backend_py.app.services.inference import YoloInferenceService


def create_tiny_png_bytes() -> bytes:
    return base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9VE0suoAAAAASUVORK5CYII="
    )


def create_test_client() -> tuple[TestClient, Path]:
    temp_root = Path(tempfile.mkdtemp(prefix="femuria-py-test-"))
    app_settings = Settings(
        local_storage_path=temp_root / "storage",
        analysis_history_path=temp_root / "storage" / "analysis_history",
        audit_log_path=temp_root / "storage" / "audit",
        frontend_path=Path.cwd() / "frontend" / "app",
        model_metadata_path=temp_root / "model-metadata.json",
    )
    app = create_app(app_settings)
    return TestClient(app), temp_root


def _fake_analyze(
    self,
    original_name: str,
    dimensions: tuple[int, int],
    fingerprint: str,  # noqa: ARG001
    image_bytes: bytes | None = None,  # noqa: ARG001
):
    width, height = dimensions
    detections = []
    if "left" in original_name.lower() or "fracture" in original_name.lower():
        detections.append(
            {
                "id": "det_model_1",
                "label": "Probable fractura de femur proximal",
                "side": "left",
                "confidence": 0.91,
                "bbox": {
                    "x": max(1, round(width * 0.16)),
                    "y": max(1, round(height * 0.28)),
                    "width": max(1, round(width * 0.18)),
                    "height": max(1, round(height * 0.2)),
                },
            }
        )

    return {
        "adapterId": "yolo_local_v1",
        "detections": detections,
        "rawSummary": (
            "Hallazgos detectados por el modelo YOLO local."
            if detections
            else "Sin hallazgos detectados por el modelo YOLO local."
        ),
    }


@pytest.fixture(autouse=True)
def patch_yolo_analyze(monkeypatch):
    monkeypatch.setattr(YoloInferenceService, "analyze", _fake_analyze)


def test_full_flow_auth_analysis_history_and_audit():
    client, temp_root = create_test_client()
    try:
        login = client.post("/api/auth/login", data={"username": "admin", "password": "admin1234"})
        assert login.status_code == 200

        me = client.get("/api/auth/me")
        assert me.status_code == 200
        assert me.json()["user"]["username"] == "admin"

        analyze = client.post(
            "/api/analysis",
            files={"image": ("fracture_left.png", create_tiny_png_bytes(), "image/png")},
        )
        assert analyze.status_code == 200
        payload = analyze.json()["analysis"]
        assert payload["overallStatus"] == "findings_detected"
        assert payload["affectedSides"] == ["left"]

        history = client.get("/api/analysis/history")
        assert history.status_code == 200
        assert len(history.json()["items"]) == 1

        audit = client.get("/api/admin/audit")
        assert audit.status_code == 200
        assert any(item["eventType"] == "analysis.created" for item in audit.json()["items"])
    finally:
        import shutil

        shutil.rmtree(temp_root, ignore_errors=True)


def test_invalid_file_and_role_protection():
    client, temp_root = create_test_client()
    try:
        login = client.post("/api/auth/login", data={"username": "medico", "password": "medico1234"})
        assert login.status_code == 200

        invalid = client.post("/api/analysis", files={"image": ("nota.txt", b"no-image", "text/plain")})
        assert invalid.status_code == 400

        audit = client.get("/api/admin/audit")
        assert audit.status_code == 403
    finally:
        import shutil

        shutil.rmtree(temp_root, ignore_errors=True)
