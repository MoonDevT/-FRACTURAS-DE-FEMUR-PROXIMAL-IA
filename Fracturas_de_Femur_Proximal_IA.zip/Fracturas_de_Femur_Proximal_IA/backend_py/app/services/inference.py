from __future__ import annotations

import json
from io import BytesIO
from typing import Any

import numpy as np
from PIL import Image


class YoloInferenceService:
    def __init__(self, settings) -> None:
        self.settings = settings
        self._model = None

    def _ensure_model(self):
        if self._model is not None:
            return self._model
        if not self.settings.model_path.exists():
            raise RuntimeError(f"No se encontro el peso del modelo en: {self.settings.model_path}")
        try:
            from ultralytics import YOLO  # type: ignore
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError(
                "No se encontro 'ultralytics'. Instale dependencias con: "
                ".venv\\Scripts\\python.exe -m pip install -r training\\requirements.txt"
            ) from exc
        self._model = YOLO(str(self.settings.model_path))
        return self._model

    @staticmethod
    def _infer_side(x: int, width: int, image_width: int) -> str:
        center = x + (width / 2)
        return "left" if center < (image_width / 2) else "right"

    def analyze(
        self,
        original_name: str,  # noqa: ARG002
        dimensions: tuple[int, int],
        fingerprint: str,  # noqa: ARG002
        image_bytes: bytes | None = None,
    ) -> dict[str, Any]:
        if not image_bytes:
            raise RuntimeError("No se recibio imagen para inferencia YOLO.")

        with Image.open(BytesIO(image_bytes)) as image:
            rgb = image.convert("RGB")
            frame = np.array(rgb)

        confidence = max(0.0, min(1.0, float(self.settings.confidence_threshold)))
        model = self._ensure_model()
        prediction = model.predict(
            source=frame,
            conf=confidence,
            iou=0.5,
            imgsz=640,
            device="cpu",
            verbose=False,
        )[0]

        img_w, img_h = dimensions
        detections: list[dict[str, Any]] = []
        for index, box in enumerate(prediction.boxes):
            x1, y1, x2, y2 = box.xyxy[0].tolist()
            x = max(0, int(round(x1)))
            y = max(0, int(round(y1)))
            width = max(1, int(round(x2 - x1)))
            height = max(1, int(round(y2 - y1)))
            side = self._infer_side(x, width, img_w)

            # Keep bboxes inside image bounds for UI consistency.
            x = min(x, max(0, img_w - 1))
            y = min(y, max(0, img_h - 1))
            width = min(width, img_w - x)
            height = min(height, img_h - y)

            detections.append(
                {
                    "id": f"det_model_{index + 1}",
                    "label": "Probable fractura de femur proximal",
                    "side": side,
                    "confidence": round(float(box.conf.item()), 4),
                    "bbox": {
                        "x": x,
                        "y": y,
                        "width": width,
                        "height": height,
                    },
                }
            )

        return {
            "adapterId": "yolo_local_v1",
            "detections": detections,
            "rawSummary": (
                "Hallazgos detectados por el modelo YOLO local."
                if detections
                else "Sin hallazgos detectados por el modelo YOLO local."
            ),
        }

    def get_model_info(self) -> dict[str, Any]:
        model_version = self.settings.model_version
        confidence_threshold = self.settings.confidence_threshold
        if self.settings.model_metadata_path.exists():
            try:
                metadata = json.loads(self.settings.model_metadata_path.read_text(encoding="utf-8"))
                model_version = str(metadata.get("modelVersion", model_version))
                confidence_threshold = float(metadata.get("confidenceThreshold", confidence_threshold))
            except (OSError, ValueError, TypeError):  # pragma: no cover
                pass

        return {
            "adapter": "yolo",
            "modelFamily": self.settings.model_family,
            "modelVersion": model_version,
            "modelPath": str(self.settings.model_path),
            "confidenceThreshold": confidence_threshold,
            "mode": "Inferencia local",
        }
