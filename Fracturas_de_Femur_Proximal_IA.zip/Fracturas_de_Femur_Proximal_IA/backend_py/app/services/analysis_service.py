﻿from __future__ import annotations

from datetime import datetime, timezone
from io import BytesIO
from typing import Any

from fastapi import HTTPException, status
from PIL import Image

from ..config import Settings
from ..storage.files import read_json, write_json
from ..utils.crypto import create_hash
from ..utils.files import detect_image_type, sanitize_file_name


class AnalysisService:
    def __init__(self, settings: Settings, audit_service, inference_service) -> None:
        self.settings = settings
        self.audit_service = audit_service
        self.inference_service = inference_service

    def _read_history(self) -> list[dict[str, Any]]:
        return read_json(self.settings.history_file_path, [])

    def _write_history(self, entries: list[dict[str, Any]]) -> None:
        write_json(self.settings.history_file_path, entries)

    @staticmethod
    def _summarize_result(detections: list[dict[str, Any]]) -> dict[str, Any]:
        if not detections:
            return {
                "overallStatus": "no_findings",
                "affectedSides": [],
                "interpretation": (
                    "No se identificó una fractura visible con el adaptador configurado. "
                    "El resultado requiere validación por personal médico."
                ),
            }

        affected_sides = sorted({item["side"] for item in detections})
        return {
            "overallStatus": "findings_detected",
            "affectedSides": affected_sides,
            "interpretation": (
                "Se identificaron hallazgos sospechosos compatibles con fractura de fémur proximal. "
                "Este resultado es de apoyo diagnóstico y requiere validación por personal médico."
            ),
        }

    def perform_analysis(
        self,
        *,
        content: bytes,
        original_name: str,
        user: dict[str, Any],
        request_meta: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        request_meta = request_meta or {}

        if not content:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Debe proporcionar una imagen válida para el análisis.",
            )

        extension = "." + original_name.split(".")[-1].lower() if "." in original_name else ""
        if extension not in self.settings.allowed_extensions:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="El formato del archivo no esta permitido.",
            )

        detected_type = detect_image_type(content)
        if not detected_type:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="El archivo no corresponde a una imagen JPG o PNG válida.",
            )

        try:
            with Image.open(BytesIO(content)) as image:
                width, height = image.size
        except Exception as exc:  # pragma: no cover
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No fue posible interpretar las dimensiones de la imagen.",
            ) from exc

        analysis_id = f"analysis_{int(datetime.now(timezone.utc).timestamp() * 1000)}"
        sanitized_name = sanitize_file_name(original_name)
        fingerprint = create_hash(content)[:16]
        inference_result = self.inference_service.analyze(
            sanitized_name,
            (width, height),
            fingerprint,
            image_bytes=content,
        )
        summary = self._summarize_result(inference_result["detections"])

        stored_file_name = None
        if self.settings.keep_uploaded_files:
            stored_file_name = f"{analysis_id}{extension}"
            (self.settings.uploads_path / stored_file_name).write_bytes(content)

        history_entry = {
            "id": analysis_id,
            "createdAt": datetime.now(timezone.utc).isoformat(),
            "actor": {"id": user["id"], "username": user["username"], "role": user["role"]},
            "file": {
                "originalName": sanitized_name,
                "mimeType": detected_type[0],
                "width": width,
                "height": height,
                "sizeBytes": len(content),
                "fingerprint": fingerprint,
                "storedFileName": stored_file_name,
            },
            "model": self.inference_service.get_model_info(),
            "detections": inference_result["detections"],
            **summary,
        }

        history = self._read_history()
        history.insert(0, history_entry)
        self._write_history(history[:500])

        self.audit_service.log(
            "analysis.created",
            user["username"],
            {
                "analysisId": analysis_id,
                "overallStatus": summary["overallStatus"],
                "affectedSides": summary["affectedSides"],
                "fileName": sanitized_name,
                "ip": request_meta.get("ip", "unknown"),
            },
        )
        return history_entry

    def list_history(self, user: dict[str, Any], limit: int = 50) -> list[dict[str, Any]]:
        history = self._read_history()
        if user["role"] in {"admin", "specialist"}:
            return history[:limit]
        return [item for item in history if item["actor"]["id"] == user["id"]][:limit]
