from __future__ import annotations

import secrets
from datetime import datetime, timezone
from typing import Any

from ..config import Settings
from ..storage.files import append_ndjson, read_ndjson


class AuditService:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    def log(self, event_type: str, actor: str, details: dict[str, Any] | None = None) -> None:
        append_ndjson(
            self.settings.audit_file_path,
            {
                "id": f"audit_{int(datetime.now(timezone.utc).timestamp() * 1000)}_{secrets.token_hex(3)}",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "eventType": event_type,
                "actor": actor,
                "details": details or {},
            },
        )

    def list(self, limit: int = 100) -> list[dict[str, Any]]:
        items = read_ndjson(self.settings.audit_file_path)
        items.reverse()
        return items[:limit]
