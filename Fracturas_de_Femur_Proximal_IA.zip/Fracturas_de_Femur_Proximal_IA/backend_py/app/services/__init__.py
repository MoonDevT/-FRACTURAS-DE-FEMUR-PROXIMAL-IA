"""Servicios del backend Python."""
