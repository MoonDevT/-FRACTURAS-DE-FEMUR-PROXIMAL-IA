﻿from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import HTTPException, status

from ..config import Settings
from ..storage.files import read_json, write_json
from ..utils.crypto import create_hash, create_token, verify_password


ROLE_LABELS = {
    "admin": "Administrador",
    "physician": "Médico General",
    "specialist": "Radiologo",
    "operator": "Técnico Operador",
}


class AuthService:
    def __init__(self, settings: Settings, audit_service) -> None:
        self.settings = settings
        self.audit_service = audit_service

    @staticmethod
    def sanitize_user(user: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": user["id"],
            "username": user["username"],
            "role": user["role"],
            "roleLabel": ROLE_LABELS.get(user["role"], user["role"]),
            "displayName": user["displayName"],
            "active": user["active"],
        }

    def _read_users(self) -> list[dict[str, Any]]:
        return read_json(self.settings.users_file_path, [])

    def _read_sessions(self) -> list[dict[str, Any]]:
        return read_json(self.settings.sessions_file_path, [])

    def _write_sessions(self, sessions: list[dict[str, Any]]) -> None:
        write_json(self.settings.sessions_file_path, sessions)

    def prune_expired_sessions(self) -> list[dict[str, Any]]:
        now = datetime.now(timezone.utc)
        active_sessions = [
            session
            for session in self._read_sessions()
            if datetime.fromisoformat(session["expiresAt"]) > now
        ]
        self._write_sessions(active_sessions)
        return active_sessions

    def create_session(self, user: dict[str, Any], request_meta: dict[str, Any] | None = None) -> dict[str, str]:
        request_meta = request_meta or {}
        token = create_token()
        token_hash = create_hash(token)
        now = datetime.now(timezone.utc)
        expires_at = now + timedelta(minutes=self.settings.session_timeout_minutes)

        sessions = self.prune_expired_sessions()
        sessions.append(
            {
                "id": f"session_{int(now.timestamp() * 1000)}",
                "userId": user["id"],
                "tokenHash": token_hash,
                "createdAt": now.isoformat(),
                "expiresAt": expires_at.isoformat(),
                "ip": request_meta.get("ip", "unknown"),
                "userAgent": request_meta.get("userAgent", "unknown"),
            }
        )
        self._write_sessions(sessions)
        return {"token": token, "expiresAt": expires_at.isoformat()}

    def login(self, username: str, password: str, request_meta: dict[str, Any] | None = None) -> dict[str, Any]:
        request_meta = request_meta or {}
        normalized_username = username.strip().lower()
        user = next(
            (
                item
                for item in self._read_users()
                if item["username"].lower() == normalized_username and item.get("active")
            ),
            None,
        )

        if not user or not verify_password(password, user["passwordHash"]):
            self.audit_service.log(
                "auth.login_failed",
                normalized_username or "unknown",
                {"ip": request_meta.get("ip", "unknown")},
            )
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Credenciales invalidas.")

        session = self.create_session(user, request_meta)
        self.audit_service.log(
            "auth.login_success",
            user["username"],
            {"role": user["role"], "ip": request_meta.get("ip", "unknown")},
        )
        return {"session": session, "user": self.sanitize_user(user)}

    def get_user_by_token(self, token: str | None) -> dict[str, Any] | None:
        if not token:
            return None

        token_hash = create_hash(token)
        session = next(
            (item for item in self.prune_expired_sessions() if item["tokenHash"] == token_hash),
            None,
        )
        if not session:
            return None

        user = next(
            (
                item
                for item in self._read_users()
                if item["id"] == session["userId"] and item.get("active")
            ),
            None,
        )
        if not user:
            return None

        return {"session": session, "user": self.sanitize_user(user)}

    def logout(self, token: str | None, actor: str = "unknown") -> None:
        if not token:
            return

        token_hash = create_hash(token)
        sessions = [item for item in self._read_sessions() if item["tokenHash"] != token_hash]
        self._write_sessions(sessions)
        self.audit_service.log("auth.logout", actor, {})
