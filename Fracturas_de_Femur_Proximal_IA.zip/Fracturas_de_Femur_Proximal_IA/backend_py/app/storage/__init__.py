"""Utilidades de almacenamiento local."""
