from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def ensure_directory(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def ensure_json_file(path: Path, fallback: Any) -> None:
    ensure_directory(path.parent)
    if not path.exists():
        path.write_text(json.dumps(fallback, indent=2), encoding="utf-8")


def read_json(path: Path, fallback: Any) -> Any:
    ensure_json_file(path, fallback)
    raw = path.read_text(encoding="utf-8").strip()
    return json.loads(raw) if raw else fallback


def write_json(path: Path, value: Any) -> None:
    ensure_directory(path.parent)
    path.write_text(json.dumps(value, indent=2), encoding="utf-8")


def append_ndjson(path: Path, value: dict[str, Any]) -> None:
    ensure_directory(path.parent)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(value) + "\n")


def read_ndjson(path: Path) -> list[dict[str, Any]]:
    ensure_directory(path.parent)
    if not path.exists():
        return []

    lines = path.read_text(encoding="utf-8").splitlines()
    return [json.loads(line) for line in lines if line.strip()]
