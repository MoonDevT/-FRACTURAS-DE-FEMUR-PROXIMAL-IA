"""Backend Python local-first para FemurIA Local."""
