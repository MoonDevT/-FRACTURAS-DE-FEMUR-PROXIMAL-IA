﻿from __future__ import annotations

import json
from datetime import datetime, timezone

from .config import Settings
from .storage.files import ensure_directory, ensure_json_file, write_json
from .utils.crypto import create_password_hash


def bootstrap_storage(settings: Settings) -> None:
    ensure_directory(settings.local_storage_path)
    ensure_directory(settings.analysis_history_path)
    ensure_directory(settings.audit_log_path)
    ensure_directory(settings.uploads_path)
    ensure_directory(settings.results_path)

    ensure_json_file(settings.users_file_path, [])
    ensure_json_file(settings.sessions_file_path, [])
    ensure_json_file(settings.history_file_path, [])

    existing_users = json.loads(settings.users_file_path.read_text(encoding="utf-8") or "[]")
    if not existing_users:
        now = datetime.now(timezone.utc).isoformat()
        seeded_users = [
            {
                "id": f"user_{index + 1}",
                "username": user.username,
                "passwordHash": create_password_hash(user.password),
                "role": user.role,
                "displayName": user.display_name,
                "active": True,
                "createdAt": now,
            }
            for index, user in enumerate(settings.default_users)
        ]
        write_json(settings.users_file_path, seeded_users)

    if not settings.model_metadata_path.exists():
        ensure_directory(settings.model_metadata_path.parent)
        settings.model_metadata_path.write_text(
            json.dumps(
                {
                    "modelFamily": settings.model_family,
                    "modelVersion": settings.model_version,
                    "modelPath": str(settings.model_path),
                    "inferenceAdapter": "yolo",
                    "createdAt": datetime.now(timezone.utc).isoformat(),
                    "notes": (
                        "Metadata local del modelo para inferencia YOLO en entorno local."
                    ),
                },
                indent=2,
            ),
            encoding="utf-8",
        )
