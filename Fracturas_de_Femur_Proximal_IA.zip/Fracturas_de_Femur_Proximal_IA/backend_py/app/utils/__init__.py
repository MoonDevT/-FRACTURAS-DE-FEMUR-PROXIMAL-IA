"""Utilidades compartidas del backend Python."""
