from __future__ import annotations

import re
from pathlib import Path


def sanitize_file_name(file_name: str) -> str:
    extension = Path(file_name).suffix.lower()
    stem = Path(file_name).stem
    stem = re.sub(r"[^a-zA-Z0-9_-]+", "_", stem)
    stem = re.sub(r"_+", "_", stem).strip("_")
    return f"{stem or 'imagen'}{extension}"


def detect_image_type(content: bytes) -> tuple[str, str] | None:
    if len(content) < 8:
        return None

    if content.startswith(b"\x89PNG\r\n\x1a\n"):
        return ("image/png", ".png")

    if content[:3] == b"\xff\xd8\xff":
        return ("image/jpeg", ".jpg")

    return None
