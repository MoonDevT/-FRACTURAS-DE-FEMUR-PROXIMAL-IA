from __future__ import annotations

import hashlib
import hmac
import secrets


def create_password_hash(password: str) -> str:
    salt = secrets.token_hex(16)
    derived_key = hashlib.scrypt(password.encode("utf-8"), salt=salt.encode("utf-8"), n=16384, r=8, p=1)
    return f"{salt}:{derived_key.hex()}"


def verify_password(password: str, stored_hash: str) -> bool:
    try:
        salt, saved_key = stored_hash.split(":", 1)
    except ValueError:
        return False

    candidate_key = hashlib.scrypt(
        password.encode("utf-8"), salt=salt.encode("utf-8"), n=16384, r=8, p=1
    ).hex()
    return hmac.compare_digest(saved_key, candidate_key)


def create_token(size: int = 32) -> str:
    return secrets.token_hex(size)


def create_hash(value: bytes | str) -> str:
    if isinstance(value, str):
        value = value.encode("utf-8")
    return hashlib.sha256(value).hexdigest()
