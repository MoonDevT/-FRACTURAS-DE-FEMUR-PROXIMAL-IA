from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from fastapi import Cookie, Depends, FastAPI, File, HTTPException, Request, Response, UploadFile, status
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from .bootstrap import bootstrap_storage
from .config import Settings, settings
from .services.analysis_service import AnalysisService
from .services.audit_service import AuditService
from .services.auth_service import AuthService
from .services.inference import YoloInferenceService


@dataclass
class AppServices:
    settings: Settings
    audit_service: AuditService
    auth_service: AuthService
    inference_service: YoloInferenceService
    analysis_service: AnalysisService


def create_services(app_settings: Settings) -> AppServices:
    bootstrap_storage(app_settings)
    audit_service = AuditService(app_settings)
    auth_service = AuthService(app_settings, audit_service)
    inference_service = YoloInferenceService(app_settings)
    analysis_service = AnalysisService(app_settings, audit_service, inference_service)
    return AppServices(
        settings=app_settings,
        audit_service=audit_service,
        auth_service=auth_service,
        inference_service=inference_service,
        analysis_service=analysis_service,
    )


def create_app(app_settings: Settings | None = None) -> FastAPI:
    active_settings = app_settings or settings
    services = create_services(active_settings)
    app = FastAPI(title=active_settings.app_name)
    app.state.services = services

    def get_services() -> AppServices:
        return app.state.services

    def get_current_user(
        session_token: str | None = Cookie(default=None, alias=active_settings.session_cookie_name),
        services: AppServices = Depends(get_services),
    ) -> dict[str, Any]:
        auth_state = services.auth_service.get_user_by_token(session_token)
        if not auth_state:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Debe iniciar sesion para continuar.",
            )
        return auth_state["user"]

    def require_roles(*roles: str):
        def dependency(user: dict[str, Any] = Depends(get_current_user)) -> dict[str, Any]:
            if user["role"] not in roles:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="No tiene permisos para realizar esta accion.",
                )
            return user

        return dependency

    @app.exception_handler(HTTPException)
    async def http_exception_handler(_request: Request, exc: HTTPException) -> JSONResponse:
        return JSONResponse(status_code=exc.status_code, content={"error": {"message": exc.detail}})

    @app.get("/api/health")
    async def health() -> dict[str, Any]:
        from datetime import datetime, timezone

        return {
            "ok": True,
            "appName": active_settings.app_name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    @app.get("/api/model")
    async def model_info(services: AppServices = Depends(get_services)) -> dict[str, Any]:
        return {"model": services.inference_service.get_model_info()}

    @app.post("/api/auth/login")
    async def login(
        response: Response,
        request: Request,
        services: AppServices = Depends(get_services),
    ) -> dict[str, Any]:
        username = ""
        password = ""

        content_type = request.headers.get("content-type", "")
        if "application/json" in content_type:
            payload = await request.json()
            username = str(payload.get("username", ""))
            password = str(payload.get("password", ""))
        else:
            form = await request.form()
            username = str(form.get("username", ""))
            password = str(form.get("password", ""))

        if not username or not password:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Debe proporcionar usuario y contrasena.",
            )

        result = services.auth_service.login(
            username,
            password,
            {
                "ip": request.client.host if request.client else "unknown",
                "userAgent": request.headers.get("user-agent", "unknown"),
            },
        )
        response.set_cookie(
            key=active_settings.session_cookie_name,
            value=result["session"]["token"],
            httponly=True,
            samesite="strict",
            max_age=active_settings.session_timeout_minutes * 60,
            path="/",
        )
        return {"user": result["user"], "expiresAt": result["session"]["expiresAt"]}

    @app.post("/api/auth/logout")
    async def logout(
        response: Response,
        current_user: dict[str, Any] = Depends(get_current_user),
        session_token: str | None = Cookie(default=None, alias=active_settings.session_cookie_name),
        services: AppServices = Depends(get_services),
    ) -> dict[str, bool]:
        services.auth_service.logout(session_token, current_user["username"])
        response.delete_cookie(active_settings.session_cookie_name, path="/")
        return {"ok": True}

    @app.get("/api/auth/me")
    async def me(current_user: dict[str, Any] = Depends(get_current_user)) -> dict[str, Any]:
        return {"user": current_user}

    @app.post("/api/analysis")
    async def analyze(
        request: Request,
        image: UploadFile = File(...),
        current_user: dict[str, Any] = Depends(get_current_user),
        services: AppServices = Depends(get_services),
    ) -> dict[str, Any]:
        content = await image.read()
        analysis = services.analysis_service.perform_analysis(
            content=content,
            original_name=image.filename or "imagen.png",
            user=current_user,
            request_meta={"ip": request.client.host if request.client else "unknown"},
        )
        return {"analysis": analysis}

    @app.get("/api/analysis/history")
    async def analysis_history(
        limit: int = 25,
        current_user: dict[str, Any] = Depends(get_current_user),
        services: AppServices = Depends(get_services),
    ) -> dict[str, Any]:
        return {"items": services.analysis_service.list_history(current_user, limit)}

    @app.get("/api/admin/audit")
    async def admin_audit(
        limit: int = 100,
        _current_user: dict[str, Any] = Depends(require_roles("admin")),
        services: AppServices = Depends(get_services),
    ) -> dict[str, Any]:
        return {"items": services.audit_service.list(limit)}

    app.mount("/", StaticFiles(directory=active_settings.frontend_path, html=True), name="static")

    return app


app = create_app()
