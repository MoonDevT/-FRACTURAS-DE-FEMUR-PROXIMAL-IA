﻿from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv


load_dotenv()


def _parse_int(value: str | None, fallback: int) -> int:
    try:
        return int(value) if value is not None else fallback
    except ValueError:
        return fallback


def _parse_float(value: str | None, fallback: float) -> float:
    try:
        return float(value) if value is not None else fallback
    except ValueError:
        return fallback


def _parse_bool(value: str | None, fallback: bool) -> bool:
    if value is None:
        return fallback
    return value.lower() in {"1", "true", "yes", "on"}


@dataclass
class DefaultUser:
    username: str
    password: str
    role: str
    display_name: str


@dataclass
class Settings:
    app_env: str = field(default_factory=lambda: os.getenv("APP_ENV", "development"))
    app_name: str = field(default_factory=lambda: os.getenv("APP_NAME", "FemurIA Local"))
    backend_host: str = field(default_factory=lambda: os.getenv("BACKEND_HOST", "127.0.0.1"))
    backend_port: int = field(default_factory=lambda: _parse_int(os.getenv("BACKEND_PORT"), 8000))
    project_root: Path = field(default_factory=lambda: Path.cwd())
    local_storage_path: Path = field(
        default_factory=lambda: Path(os.getenv("LOCAL_STORAGE_PATH", "data/local_storage")).resolve()
    )
    analysis_history_path: Path = field(
        default_factory=lambda: Path(
            os.getenv("ANALYSIS_HISTORY_PATH", "data/local_storage/analysis_history")
        ).resolve()
    )
    audit_log_path: Path = field(
        default_factory=lambda: Path(os.getenv("AUDIT_LOG_PATH", "data/local_storage/audit")).resolve()
    )
    model_path: Path = field(
        default_factory=lambda: Path(os.getenv("MODEL_PATH", "models/exports/best.pt")).resolve()
    )
    model_metadata_path: Path = field(
        default_factory=lambda: Path(
            os.getenv("MODEL_METADATA_PATH", "models/exports/model-metadata.json")
        ).resolve()
    )
    model_family: str = field(default_factory=lambda: os.getenv("MODEL_FAMILY", "YOLOv8"))
    model_version: str = field(default_factory=lambda: os.getenv("MODEL_VERSION", "0.3.0"))
    confidence_threshold: float = field(
        default_factory=lambda: _parse_float(os.getenv("CONFIDENCE_THRESHOLD"), 0.25)
    )
    session_secret: str = field(
        default_factory=lambda: os.getenv("SESSION_SECRET", "change_this_local_secret")
    )
    session_cookie_name: str = field(
        default_factory=lambda: os.getenv("SESSION_COOKIE_NAME", "prox_femur_session")
    )
    session_timeout_minutes: int = field(
        default_factory=lambda: _parse_int(os.getenv("SESSION_TIMEOUT_MINUTES"), 60)
    )
    max_upload_mb: int = field(default_factory=lambda: _parse_int(os.getenv("MAX_UPLOAD_MB"), 10))
    keep_uploaded_files: bool = field(
        default_factory=lambda: _parse_bool(os.getenv("KEEP_UPLOADED_FILES"), True)
    )
    frontend_path: Path = field(default_factory=lambda: Path("frontend/app").resolve())
    allowed_extensions: set[str] = field(default_factory=lambda: {".jpg", ".jpeg", ".png"})
    default_users: list[DefaultUser] = field(
        default_factory=lambda: [
            DefaultUser(
                username=os.getenv("DEFAULT_ADMIN_USER", "admin"),
                password=os.getenv("DEFAULT_ADMIN_PASSWORD", "admin1234"),
                role="admin",
                display_name="Administrador Local",
            ),
            DefaultUser(
                username=os.getenv("DEFAULT_PHYSICIAN_USER", "medico"),
                password=os.getenv("DEFAULT_PHYSICIAN_PASSWORD", "medico1234"),
                role="physician",
                display_name="Médico General",
            ),
            DefaultUser(
                username=os.getenv("DEFAULT_SPECIALIST_USER", "radiologo"),
                password=os.getenv("DEFAULT_SPECIALIST_PASSWORD", "radiologo1234"),
                role="specialist",
                display_name="Radiologo",
            ),
            DefaultUser(
                username=os.getenv("DEFAULT_OPERATOR_USER", "tecnico"),
                password=os.getenv("DEFAULT_OPERATOR_PASSWORD", "tecnico1234"),
                role="operator",
                display_name="Técnico Operador",
            ),
        ]
    )

    @property
    def uploads_path(self) -> Path:
        return self.local_storage_path / "uploads"

    @property
    def results_path(self) -> Path:
        return self.local_storage_path / "results"

    @property
    def users_file_path(self) -> Path:
        return self.local_storage_path / "users.json"

    @property
    def sessions_file_path(self) -> Path:
        return self.local_storage_path / "sessions.json"

    @property
    def history_file_path(self) -> Path:
        return self.analysis_history_path / "history.json"

    @property
    def audit_file_path(self) -> Path:
        return self.audit_log_path / "audit.ndjson"


settings = Settings()
