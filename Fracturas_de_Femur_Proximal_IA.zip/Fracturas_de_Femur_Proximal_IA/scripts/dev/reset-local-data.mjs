import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const target = path.join(root, "data", "local_storage");

if (fs.existsSync(target)) {
  fs.rmSync(target, { recursive: true, force: true });
}

fs.mkdirSync(path.join(target, "analysis_history"), { recursive: true });
fs.mkdirSync(path.join(target, "audit"), { recursive: true });

console.log("Almacenamiento local reiniciado:", target);
