﻿# Fracturas de Femur Proximal IA

Aplicacion local de apoyo diagnostico para detectar hallazgos sospechosos de fractura de femur proximal en radiografias digitalizadas.

Este sistema no emite diagnostico definitivo: entrega una sugerencia de deteccion que debe ser validada por personal medico.

## Que incluye hoy

- Frontend web institucional en `frontend/app/`
- Backend local en Python (FastAPI) en `backend_py/`
- Login local con roles y sesion por cookie
- Carga y validacion estricta de imagenes `.jpg`, `.jpeg` y `.png`
- Inferencia YOLO local (sin APIs externas)
- Visualizacion de recuadros de deteccion, coordenadas y confianza
- Historial local de analisis y bitacora auditable

## Requisitos

- Windows, Linux o macOS
- Python 3.12 recomendado
- `pip` disponible
- (Opcional) Node.js 20+ para utilidades con `npm`
- Archivo de pesos YOLO exportado en `models/exports/best.pt`

## Estructura del repo

```text
.
|-- README.md
|-- .env.example
|-- backend/
|-- backend_py/
|-- data/
|-- frontend/
|-- models/
|-- notebooks/
|-- scripts/
|-- tests/
`-- training/
```

## Configuracion en una PC nueva

1. Clonar el repositorio y entrar a la carpeta del proyecto.
2. Crear entorno virtual:

```powershell
python -m venv .venv
```

3. Activar entorno virtual:

```powershell
.venv\Scripts\Activate.ps1
```

En Linux/macOS:

```bash
source .venv/bin/activate
```

4. Instalar dependencias del backend Python:

```powershell
python -m pip install --upgrade pip
python -m pip install -r backend_py/requirements.txt
```

5. Crear archivo `.env` a partir de `.env.example`:

```powershell
Copy-Item .env.example .env
```

En Linux/macOS:

```bash
cp .env.example .env
```

6. Editar `.env` y revisar como minimo:

- `SESSION_SECRET` (obligatorio cambiarlo)
- `MODEL_PATH` (por defecto `models/exports/best.pt`)
- `CONFIDENCE_THRESHOLD` (por defecto `0.25`)
- `BACKEND_HOST` y `BACKEND_PORT` (por defecto `127.0.0.1:8000`)

7. Verificar que exista el modelo en la ruta definida por `MODEL_PATH`.

## Ejecucion

Con el entorno virtual activo:

```powershell
python backend_py/run.py
```

Abrir en navegador:

```text
http://127.0.0.1:8000
```

## Credenciales iniciales locales

- `admin` / `admin1234`
- `medico` / `medico1234`
- `radiologo` / `radiologo1234`
- `tecnico` / `tecnico1234`

Recomendacion: cambiar contrasenas inmediatamente en el entorno destino.

## Datos locales que genera la app

Durante la ejecucion se crean/actualizan rutas locales como:

- `data/local_storage/uploads/`
- `data/local_storage/results/`
- `data/local_storage/analysis_history/history.json`
- `data/local_storage/audit/audit.ndjson`
- `data/local_storage/users.json`
- `data/local_storage/sessions.json`

## Pruebas y verificacion de flujo

Pruebas backend Python:

```powershell
python -m pytest backend_py/tests/test_app.py
```

Pruebas Node (si usas el backend JS legado o quieres validar utilidades):

```powershell
npm install
npm test
```

## Solucion rapida de problemas

- Error de modelo no encontrado: revisar `MODEL_PATH` y confirmar que el archivo existe.
- Error al importar `ultralytics`: reinstalar dependencias con `pip install -r backend_py/requirements.txt`.
- Puerto ocupado: cambiar `BACKEND_PORT` en `.env`.
- Error de sesion/cookies: limpiar cookies del navegador y volver a iniciar sesion.

## Consideraciones operativas

- Operacion local-first: no depende de internet en produccion.
- No envia imagenes ni metadatos a terceros.
- Pensado como apoyo diagnostico institucional, no diagnostico autonomo.
