from __future__ import annotations

import argparse
import csv
import json
import random
import re
import shutil
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

from PIL import Image, UnidentifiedImageError


IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}


@dataclass
class Sample:
    image_path: Path
    label_path: Path
    has_label: bool
    relative_key: str


def _slugify(value: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9_-]+", "_", value.strip())
    return cleaned.strip("_") or "image"


def _discover_images(images_dir: Path) -> list[Path]:
    return sorted(
        path
        for path in images_dir.rglob("*")
        if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS
    )


def _validate_yolo_label_file(label_path: Path) -> bool:
    try:
        content = label_path.read_text(encoding="utf-8").splitlines()
    except UnicodeDecodeError:
        return False

    for line in content:
        stripped = line.strip()
        if not stripped:
            continue
        parts = stripped.split()
        if len(parts) != 5:
            return False
        try:
            class_id = int(float(parts[0]))
            cx, cy, w, h = (float(parts[idx]) for idx in range(1, 5))
        except ValueError:
            return False
        if class_id < 0:
            return False
        if not (0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0 and 0.0 < w <= 1.0 and 0.0 < h <= 1.0):
            return False
    return True


def _infer_label_path(image_path: Path, images_dir: Path, labels_dir: Path | None) -> Path:
    if labels_dir is not None:
        rel = image_path.relative_to(images_dir).with_suffix(".txt")
        return labels_dir / rel
    return image_path.with_suffix(".txt")


def _build_samples(images_dir: Path, labels_dir: Path | None) -> list[Sample]:
    images = _discover_images(images_dir)
    samples: list[Sample] = []
    for image_path in images:
        label_path = _infer_label_path(image_path, images_dir, labels_dir)
        has_label = label_path.exists() and _validate_yolo_label_file(label_path)
        relative_key = _slugify(str(image_path.relative_to(images_dir).with_suffix("")))
        samples.append(
            Sample(
                image_path=image_path,
                label_path=label_path,
                has_label=has_label,
                relative_key=relative_key,
            )
        )
    return samples


def _split_counts(total: int, train_ratio: float, val_ratio: float) -> tuple[int, int, int]:
    train_count = int(total * train_ratio)
    val_count = int(total * val_ratio)
    test_count = total - train_count - val_count
    return train_count, val_count, test_count


def _write_image_as_jpg(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        with Image.open(source) as image:
            rgb = image.convert("RGB")
            rgb.save(target, format="JPEG", quality=95)
    except (UnidentifiedImageError, OSError) as exc:
        raise RuntimeError(f"No se pudo leer la imagen '{source}'.") from exc


def _copy_label(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def _write_data_yaml(output_dir: Path, class_names: list[str]) -> Path:
    yaml_path = output_dir / "data.yaml"
    lines = [
        f"path: {output_dir.as_posix()}",
        "train: images/train",
        "val: images/val",
        "test: images/test",
        "names:",
    ]
    for idx, class_name in enumerate(class_names):
        lines.append(f"  {idx}: {class_name}")
    yaml_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return yaml_path


def _write_unlabeled_report(output_dir: Path, unlabeled: Iterable[Sample]) -> Path:
    report_path = output_dir / "unlabeled_images.csv"
    with report_path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["image_path", "suggested_label_path"])
        for sample in unlabeled:
            writer.writerow([str(sample.image_path), str(sample.label_path)])
    return report_path


def _prepare_dataset(args: argparse.Namespace) -> dict[str, object]:
    images_dir = Path(args.images_dir).resolve()
    labels_dir = Path(args.labels_dir).resolve() if args.labels_dir else None
    output_dir = Path(args.output_dir).resolve()
    class_names = [item.strip() for item in args.class_names.split(",") if item.strip()]
    if not class_names:
        raise ValueError("Debe proporcionar al menos un nombre de clase en --class-names.")

    if not images_dir.exists():
        raise FileNotFoundError(f"No existe la carpeta de imagenes: {images_dir}")
    if labels_dir is not None and not labels_dir.exists():
        raise FileNotFoundError(f"No existe la carpeta de etiquetas: {labels_dir}")

    output_dir.mkdir(parents=True, exist_ok=True)
    for split in ("train", "val", "test"):
        (output_dir / "images" / split).mkdir(parents=True, exist_ok=True)
        (output_dir / "labels" / split).mkdir(parents=True, exist_ok=True)

    samples = _build_samples(images_dir, labels_dir)
    labeled_samples = [sample for sample in samples if sample.has_label]
    unlabeled_samples = [sample for sample in samples if not sample.has_label]

    if len(labeled_samples) == 0:
        report_path = _write_unlabeled_report(output_dir, unlabeled_samples)
        raise RuntimeError(
            "No se encontraron etiquetas YOLO validas. "
            f"Se genero el reporte de pendientes en: {report_path}"
        )

    rng = random.Random(args.seed)
    rng.shuffle(labeled_samples)

    train_count, val_count, _test_count = _split_counts(
        len(labeled_samples), args.train_ratio, args.val_ratio
    )
    train_samples = labeled_samples[:train_count]
    val_samples = labeled_samples[train_count : train_count + val_count]
    test_samples = labeled_samples[train_count + val_count :]

    split_map = {
        "train": train_samples,
        "val": val_samples,
        "test": test_samples,
    }

    index = 0
    for split_name, split_samples in split_map.items():
        for sample in split_samples:
            index += 1
            base_name = f"{index:06d}_{sample.relative_key}"
            image_target = output_dir / "images" / split_name / f"{base_name}.jpg"
            label_target = output_dir / "labels" / split_name / f"{base_name}.txt"
            _write_image_as_jpg(sample.image_path, image_target)
            _copy_label(sample.label_path, label_target)

    data_yaml_path = _write_data_yaml(output_dir, class_names)
    unlabeled_report_path = _write_unlabeled_report(output_dir, unlabeled_samples)

    summary = {
        "createdAt": datetime.now(timezone.utc).isoformat(),
        "outputDir": str(output_dir),
        "dataYaml": str(data_yaml_path),
        "totalImagesFound": len(samples),
        "labeledImagesUsed": len(labeled_samples),
        "unlabeledImages": len(unlabeled_samples),
        "split": {
            "train": len(train_samples),
            "val": len(val_samples),
            "test": len(test_samples),
        },
        "unlabeledReport": str(unlabeled_report_path),
        "classNames": class_names,
    }
    (output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return summary


def _print_prepare_summary(summary: dict[str, object]) -> None:
    split = summary["split"]
    print("Preparacion completada.")
    print(f"- Dataset procesado: {summary['outputDir']}")
    print(f"- data.yaml: {summary['dataYaml']}")
    print(f"- Imagenes detectadas: {summary['totalImagesFound']}")
    print(f"- Imagenes etiquetadas usadas: {summary['labeledImagesUsed']}")
    print(f"- Imagenes sin etiqueta: {summary['unlabeledImages']}")
    print(f"- Split train/val/test: {split['train']}/{split['val']}/{split['test']}")
    print(f"- Reporte de no etiquetadas: {summary['unlabeledReport']}")


def _run_train(args: argparse.Namespace) -> dict[str, object]:
    try:
        from ultralytics import YOLO  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "No se encontro ultralytics. Instala dependencias con:\n"
            ".venv\\Scripts\\python.exe -m pip install -r training\\requirements.txt"
        ) from exc

    data_yaml = Path(args.data_yaml).resolve()
    if not data_yaml.exists():
        raise FileNotFoundError(f"No existe data.yaml: {data_yaml}")

    model = YOLO(args.model)
    results = model.train(
        data=str(data_yaml),
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        project=args.project,
        name=args.name,
        patience=args.patience,
        workers=args.workers,
        device=args.device,
        pretrained=True,
        seed=args.seed,
    )

    save_dir = Path(getattr(results, "save_dir", Path(args.project) / args.name))
    best_weights = save_dir / "weights" / "best.pt"
    if not best_weights.exists():
        raise RuntimeError("No se encontro el archivo best.pt al finalizar el entrenamiento.")

    exports_dir = Path("models/exports").resolve()
    exports_dir.mkdir(parents=True, exist_ok=True)
    exported_weights = exports_dir / "best.pt"
    shutil.copy2(best_weights, exported_weights)

    model_metadata = {
        "modelFamily": "YOLOv8",
        "modelVersion": args.model_version,
        "modelPath": str(exported_weights),
        "confidenceThreshold": args.confidence_threshold,
        "trainedAt": datetime.now(timezone.utc).isoformat(),
        "trainingRunDir": str(save_dir.resolve()),
        "dataYaml": str(data_yaml),
    }
    metadata_path = exports_dir / "model-metadata.json"
    metadata_path.write_text(json.dumps(model_metadata, ensure_ascii=False, indent=2), encoding="utf-8")

    print("Entrenamiento completado.")
    print(f"- Run: {save_dir.resolve()}")
    print(f"- Pesos exportados: {exported_weights}")
    print(f"- Metadatos: {metadata_path}")
    return {
        "saveDir": str(save_dir.resolve()),
        "bestWeights": str(exported_weights),
        "metadataPath": str(metadata_path),
    }


def _run_auto(args: argparse.Namespace) -> None:
    summary = _prepare_dataset(args)
    _print_prepare_summary(summary)
    if int(summary["labeledImagesUsed"]) < args.min_labeled_images:
        raise RuntimeError(
            f"Solo hay {summary['labeledImagesUsed']} imagenes etiquetadas. "
            f"Se requieren al menos {args.min_labeled_images} para entrenar con esta receta."
        )

    train_args = argparse.Namespace(
        data_yaml=summary["dataYaml"],
        model=args.model,
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        project=args.project,
        name=args.name,
        patience=args.patience,
        workers=args.workers,
        device=args.device,
        seed=args.seed,
        model_version=args.model_version,
        confidence_threshold=args.confidence_threshold,
    )
    _run_train(train_args)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Pipeline casi automatico para preparar y entrenar YOLO con radiografias."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    def add_prepare_args(target: argparse.ArgumentParser) -> None:
        target.add_argument("--images-dir", default="data/raw", help="Carpeta con imagenes origen.")
        target.add_argument(
            "--labels-dir",
            default="data/annotations",
            help="Carpeta con etiquetas YOLO (.txt) respetando estructura relativa.",
        )
        target.add_argument(
            "--output-dir",
            default="data/processed/femur_dataset_v1",
            help="Carpeta destino del dataset procesado.",
        )
        target.add_argument("--train-ratio", type=float, default=0.7, help="Proporcion para train.")
        target.add_argument("--val-ratio", type=float, default=0.2, help="Proporcion para val.")
        target.add_argument("--seed", type=int, default=42, help="Semilla para split reproducible.")
        target.add_argument(
            "--class-names",
            default="proximal_femur_fracture",
            help="Nombres de clase separados por coma.",
        )

    prepare_parser = subparsers.add_parser("prepare", help="Prepara dataset YOLO desde imagenes/labels.")
    add_prepare_args(prepare_parser)

    train_parser = subparsers.add_parser("train", help="Entrena YOLO con un data.yaml ya preparado.")
    train_parser.add_argument(
        "--data-yaml",
        default="data/processed/femur_dataset_v1/data.yaml",
        help="Ruta a data.yaml generado por 'prepare'.",
    )
    train_parser.add_argument("--model", default="yolov8n.pt", help="Checkpoint base de YOLO.")
    train_parser.add_argument("--epochs", type=int, default=120, help="Numero de epocas.")
    train_parser.add_argument("--imgsz", type=int, default=960, help="Resolucion de entrenamiento.")
    train_parser.add_argument("--batch", type=int, default=8, help="Batch size.")
    train_parser.add_argument("--project", default="training/runs", help="Directorio de runs.")
    train_parser.add_argument("--name", default="femur_baseline", help="Nombre de la corrida.")
    train_parser.add_argument("--patience", type=int, default=25, help="Early stopping patience.")
    train_parser.add_argument("--workers", type=int, default=4, help="Numero de workers.")
    train_parser.add_argument("--device", default="cpu", help="cpu, 0, 0,1, etc.")
    train_parser.add_argument("--seed", type=int, default=42, help="Semilla.")
    train_parser.add_argument(
        "--model-version",
        default="0.2.0-train-local",
        help="Version que se escribira en model-metadata.json.",
    )
    train_parser.add_argument(
        "--confidence-threshold",
        type=float,
        default=0.25,
        help="Umbral de confianza para metadatos de inferencia.",
    )

    auto_parser = subparsers.add_parser(
        "auto",
        help="Ejecuta prepare + train en un solo flujo (si hay etiquetas suficientes).",
    )
    add_prepare_args(auto_parser)
    auto_parser.add_argument("--model", default="yolov8n.pt")
    auto_parser.add_argument("--epochs", type=int, default=120)
    auto_parser.add_argument("--imgsz", type=int, default=960)
    auto_parser.add_argument("--batch", type=int, default=8)
    auto_parser.add_argument("--project", default="training/runs")
    auto_parser.add_argument("--name", default="femur_auto")
    auto_parser.add_argument("--patience", type=int, default=25)
    auto_parser.add_argument("--workers", type=int, default=4)
    auto_parser.add_argument("--device", default="cpu")
    auto_parser.add_argument("--model-version", default="0.2.0-train-auto")
    auto_parser.add_argument("--confidence-threshold", type=float, default=0.25)
    auto_parser.add_argument(
        "--min-labeled-images",
        type=int,
        default=80,
        help="Minimo de imagenes etiquetadas para arrancar entrenamiento automatico.",
    )
    return parser


def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()

    if args.command in {"prepare", "auto"}:
        if not (0.0 < args.train_ratio < 1.0):
            raise ValueError("--train-ratio debe estar entre 0 y 1.")
        if not (0.0 < args.val_ratio < 1.0):
            raise ValueError("--val-ratio debe estar entre 0 y 1.")
        if args.train_ratio + args.val_ratio >= 1.0:
            raise ValueError("La suma de --train-ratio y --val-ratio debe ser menor que 1.")

    try:
        if args.command == "prepare":
            summary = _prepare_dataset(args)
            _print_prepare_summary(summary)
        elif args.command == "train":
            _run_train(args)
        elif args.command == "auto":
            _run_auto(args)
        else:
            parser.print_help()
            return 1
    except Exception as exc:  # noqa: BLE001
        print(f"[ERROR] {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
