from __future__ import annotations

import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

from ultralytics import YOLO


IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg"}


def _find_first_image(images_dir: Path) -> Path:
    for file_path in sorted(images_dir.rglob("*")):
        if file_path.is_file() and file_path.suffix.lower() in IMAGE_EXTENSIONS:
            return file_path
    raise RuntimeError(f"No se encontró ninguna imagen en: {images_dir}")


def _prepare_smoke_dataset(image_path: Path, label_path: Path, output_dir: Path) -> Path:
    if not label_path.exists():
        raise RuntimeError(f"No se encontró etiqueta YOLO para la imagen: {label_path}")

    for split in ("train", "val"):
        (output_dir / "images" / split).mkdir(parents=True, exist_ok=True)
        (output_dir / "labels" / split).mkdir(parents=True, exist_ok=True)
        shutil.copy2(image_path, output_dir / "images" / split / image_path.name)
        shutil.copy2(label_path, output_dir / "labels" / split / label_path.name)

    data_yaml = output_dir / "data.yaml"
    data_yaml.write_text(
        "\n".join(
            [
                f"path: {output_dir.as_posix()}",
                "train: images/train",
                "val: images/val",
                "names:",
                "  0: proximal_femur_fracture",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    return data_yaml


def main() -> int:
    images_dir = Path("dataset/images/train").resolve()
    labels_dir = Path("dataset/labels/train").resolve()
    smoke_dir = Path("data/processed/smoke_one_image").resolve()

    image_path = _find_first_image(images_dir)
    label_path = labels_dir / image_path.with_suffix(".txt").name
    data_yaml = _prepare_smoke_dataset(image_path, label_path, smoke_dir)

    model = YOLO("yolov8n.pt")
    results = model.train(
        data=str(data_yaml),
        epochs=200,
        imgsz=640,
        batch=1,
        workers=0,
        device="cpu",
        project="training/runs",
        name="smoke_1img_overfit_noaug",
        patience=0,
        pretrained=True,
        seed=42,
        mosaic=0.0,
        mixup=0.0,
        copy_paste=0.0,
        degrees=0.0,
        translate=0.0,
        scale=0.0,
        shear=0.0,
        perspective=0.0,
        fliplr=0.0,
        flipud=0.0,
        hsv_h=0.0,
        hsv_s=0.0,
        hsv_v=0.0,
    )

    save_dir = Path(getattr(results, "save_dir", Path("training/runs/smoke_1img_overfit_noaug")))
    best_weights = save_dir / "weights" / "best.pt"
    if not best_weights.exists():
        raise RuntimeError("No se generó best.pt en el smoke test.")

    exports_dir = Path("models/exports").resolve()
    exports_dir.mkdir(parents=True, exist_ok=True)
    exported_weights = exports_dir / "best.pt"
    shutil.copy2(best_weights, exported_weights)

    metadata = {
        "modelFamily": "YOLOv8",
        "modelVersion": "0.0.3-smoke-overfit-noaug",
        "modelPath": str(exported_weights),
        "confidenceThreshold": 0.25,
        "trainedAt": datetime.now(timezone.utc).isoformat(),
        "trainingRunDir": str(save_dir.resolve()),
        "dataYaml": str(data_yaml),
    }
    metadata_path = exports_dir / "model-metadata.json"
    metadata_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")

    pred = model.predict(
        source=str(image_path),
        conf=0.25,
        iou=0.5,
        imgsz=640,
        device="cpu",
        verbose=False,
    )[0]
    detections = len(pred.boxes)

    print("Smoke test completado.")
    print(f"- Imagen usada: {image_path}")
    print(f"- Etiqueta usada: {label_path}")
    print(f"- data.yaml: {data_yaml}")
    print(f"- Run: {save_dir.resolve()}")
    print(f"- Pesos exportados: {exported_weights}")
    print(f"- Metadatos: {metadata_path}")
    print(f"- Detecciones sobre la misma imagen (conf>=0.25): {detections}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
