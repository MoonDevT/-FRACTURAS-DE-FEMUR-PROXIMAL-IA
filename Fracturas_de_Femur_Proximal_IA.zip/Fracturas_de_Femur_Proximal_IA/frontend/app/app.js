﻿const state = {
  user: null,
  analysis: null,
  selectedFile: null,
  imageUrl: null,
  model: null,
  historyItems: [],
  activeView: "home"
};

const elements = {
  appShell: document.querySelector(".app-shell"),
  authCard: document.getElementById("auth-card"),
  dashboard: document.getElementById("dashboard"),
  loginForm: document.getElementById("login-form"),
  authFeedback: document.getElementById("auth-feedback"),
  logoutButton: document.getElementById("logout-button"),
  sessionRoleLabel: document.getElementById("session-role-label"),
  navLinks: [...document.querySelectorAll(".top-nav-link")],
  quickNavButtons: [...document.querySelectorAll("[data-go-view]")],
  viewPages: [...document.querySelectorAll(".view-page")],
  imageInput: document.getElementById("image-input"),
  selectedFileLabel: document.getElementById("selected-file-label"),
  analysisForm: document.getElementById("analysis-form"),
  analyzeButton: document.getElementById("analyze-button"),
  viewerCanvas: document.getElementById("viewer-canvas"),
  viewerOverlay: document.getElementById("viewer-overlay"),
  statusBox: document.getElementById("status-box"),
  roleGuidance: document.getElementById("role-guidance"),
  statusTitle: document.getElementById("status-title"),
  statusMessage: document.getElementById("status-message"),
  statusDetail: document.getElementById("status-detail"),
  resultMeta: document.getElementById("result-meta"),
  historyList: document.getElementById("history-list"),
  auditCard: document.getElementById("audit-card"),
  auditList: document.getElementById("audit-list"),
  modelBadge: document.getElementById("model-badge"),
  thresholdBadge: document.getElementById("threshold-badge"),
  dailyAnalyses: document.getElementById("daily-analyses"),
  systemState: document.getElementById("system-state")
};

const canvasContext = elements.viewerCanvas.getContext("2d");
const ALLOWED_EXTENSIONS = new Set(["jpg", "jpeg", "png"]);

function roleName(role) {
  return (
    {
      admin: "Administrador",
      physician: "Médico General",
      specialist: "Radiólogo",
      operator: "Técnico Operador"
    }[role] || role
  );
}

function roleGuidance(role) {
  return (
    {
      admin: "Supervise bitácora y consistencia de sesiones durante la operación diaria.",
      physician: "Use este resultado como apoyo y confirme todo hallazgo con criterio médico.",
      specialist: "Revise lateralidad, coordenadas y confianza para soporte de validación radiológica.",
      operator: "Verifique formato y calidad de imagen antes de ejecutar un nuevo análisis."
    }[role] || "Inicie sesión para ver recomendaciones operativas por perfil."
  );
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function formatDate(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return "Fecha no disponible";
  }
  return date.toLocaleString();
}

function setAuthFeedback(message = "", tone = "error") {
  if (!message) {
    elements.authFeedback.className = "auth-feedback hidden";
    elements.authFeedback.textContent = "";
    return;
  }

  elements.authFeedback.className = `auth-feedback ${tone}`;
  elements.authFeedback.textContent = message;
}

async function apiFetch(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      ...(options.body instanceof FormData ? {} : { "Content-Type": "application/json" }),
      ...(options.headers || {})
    }
  });

  const isJson = response.headers.get("content-type")?.includes("application/json");
  const payload = isJson ? await response.json() : null;

  if (!response.ok) {
    const message = payload?.error?.message || "No fue posible completar la operación.";
    throw new Error(message);
  }

  return payload;
}

function setSystemState(message, tone = "neutral") {
  elements.systemState.className = `metric-value metric-state ${tone}`;
  elements.systemState.textContent = message;
}

function setStatus(message, tone = "neutral", detail = "No existe un análisis en ejecución.") {
  const titleByTone = {
    neutral: "Predicción pendiente",
    processing: "Análisis en ejecución",
    success: "Sin hallazgo sugerido",
    findings: "Hallazgo sugerido",
    error: "Error de operación"
  };

  elements.statusBox.className = `status-box tone-${tone}`;
  elements.statusTitle.textContent = titleByTone[tone] || titleByTone.neutral;
  elements.statusMessage.textContent = message;
  elements.statusDetail.textContent = detail;

  if (tone === "success") {
    setSystemState("Análisis completado", "success");
  } else if (tone === "processing") {
    setSystemState("Procesando imagen", "warning");
  } else if (tone === "findings") {
    setSystemState("Hallazgo sugerido", "warning");
  } else if (tone === "error") {
    setSystemState("Revisión requerida", "warning");
  } else {
    setSystemState(state.user ? "Sesión activa" : "Esperando operación", state.user ? "success" : "neutral");
  }
}

function setAnalyzing(isAnalyzing) {
  elements.analyzeButton.disabled = isAnalyzing;
  elements.analyzeButton.textContent = isAnalyzing ? "Procesando..." : "Analizar imagen";
  elements.viewerOverlay.classList.toggle("is-active", isAnalyzing);
  elements.viewerOverlay.setAttribute("aria-hidden", String(!isAnalyzing));
}

function clearCanvas(message = "Sin imagen cargada.") {
  const { width, height } = elements.viewerCanvas;
  canvasContext.clearRect(0, 0, width, height);
  canvasContext.fillStyle = "#f1f5f9";
  canvasContext.fillRect(0, 0, width, height);
  canvasContext.fillStyle = "#475569";
  canvasContext.font = "600 24px 'IBM Plex Sans', 'Segoe UI', sans-serif";
  canvasContext.textAlign = "center";
  canvasContext.textBaseline = "middle";
  canvasContext.fillText(message, width / 2, height / 2);
}

async function renderImageWithDetections() {
  if (!state.imageUrl) {
    clearCanvas();
    return;
  }

  const image = new Image();
  image.src = state.imageUrl;
  await image.decode();

  const { width, height } = elements.viewerCanvas;
  canvasContext.clearRect(0, 0, width, height);

  const scale = Math.min(width / image.width, height / image.height);
  const drawWidth = image.width * scale;
  const drawHeight = image.height * scale;
  const offsetX = (width - drawWidth) / 2;
  const offsetY = (height - drawHeight) / 2;

  canvasContext.fillStyle = "#e2e8f0";
  canvasContext.fillRect(0, 0, width, height);
  canvasContext.drawImage(image, offsetX, offsetY, drawWidth, drawHeight);

  const detections = state.analysis?.detections || [];
  detections.forEach((detection) => {
    const x = offsetX + detection.bbox.x * scale;
    const y = offsetY + detection.bbox.y * scale;
    const boxWidth = detection.bbox.width * scale;
    const boxHeight = detection.bbox.height * scale;

    canvasContext.strokeStyle = "#dc2626";
    canvasContext.lineWidth = 3;
    canvasContext.strokeRect(x, y, boxWidth, boxHeight);

    const label = `${detection.side.toUpperCase()} ${(detection.confidence * 100).toFixed(1)}%`;
    canvasContext.font = "600 13px 'IBM Plex Sans', 'Segoe UI', sans-serif";
    const metrics = canvasContext.measureText(label);
    const labelWidth = metrics.width + 16;
    const labelY = Math.max(offsetY + 8, y - 30);

    canvasContext.fillStyle = "#dc2626";
    canvasContext.fillRect(x, labelY, labelWidth, 24);
    canvasContext.fillStyle = "#ffffff";
    canvasContext.fillText(label, x + 8, labelY + 17);
  });
}

function renderResult() {
  if (!state.analysis) {
    elements.resultMeta.innerHTML = '<p class="empty-copy">Sin análisis reciente.</p>';
    setStatus(
      "Sistema listo para recibir una radiografía.",
      "neutral",
      "No existe un análisis en ejecución."
    );
    return;
  }

  const analysis = state.analysis;
  if (analysis.overallStatus === "findings_detected") {
    const sides = analysis.affectedSides.length ? analysis.affectedSides.join(", ") : "sin lateralidad definida";
    setStatus(
      `Hallazgos sospechosos detectados en ${sides}.`,
      "findings",
      "Resultado de apoyo diagnóstico. Requiere validación por personal médico."
    );
  } else {
    setStatus(
      "No se detectó una fractura visible con el modelo configurado.",
      "success",
      "Si lo requiere, cargue otra imagen para contraste."
    );
  }

  const detectionsMarkup =
    analysis.detections.length === 0
      ? `
        <article class="result-item">
          <p class="result-item-title">Detecciones</p>
          <p class="result-item-value">Sin hallazgos visibles.</p>
        </article>
      `
      : analysis.detections
          .map(
            (detection) => `
              <article class="result-item">
                <p class="result-item-title">${escapeHtml(detection.label)}</p>
                <p class="result-item-value">${escapeHtml(detection.side.toUpperCase())}</p>
                <p class="result-item-meta">Confianza: ${(detection.confidence * 100).toFixed(1)}%</p>
                <p class="result-item-meta">x=${detection.bbox.x}, y=${detection.bbox.y}, w=${detection.bbox.width}, h=${detection.bbox.height}</p>
              </article>
            `
          )
          .join("");

  elements.resultMeta.innerHTML = `
    <article class="result-item">
      <p class="result-item-title">Archivo</p>
      <p class="result-item-value">${escapeHtml(analysis.file.originalName)}</p>
      <p class="result-item-meta">${analysis.file.width} x ${analysis.file.height}px</p>
    </article>
    <article class="result-item">
      <p class="result-item-title">Resultado interpretativo</p>
      <p class="result-item-value">${escapeHtml(analysis.interpretation)}</p>
    </article>
    ${detectionsMarkup}
  `;
}

function renderHistory(items) {
  if (!items.length) {
    elements.historyList.innerHTML = '<p class="empty-copy">Sin registros.</p>';
    elements.dailyAnalyses.textContent = "0";
    return;
  }

  const today = new Date().toDateString();
  const analysesToday = items.filter((item) => new Date(item.createdAt).toDateString() === today).length;
  elements.dailyAnalyses.textContent = String(analysesToday);

  elements.historyList.innerHTML = items
    .map(
      (item) => `
        <article class="feed-item">
          <div class="feed-item-head">
            <p class="feed-date">${formatDate(item.createdAt)}</p>
            <span class="badge ${item.overallStatus === "findings_detected" ? "finding" : "clean"}">
              ${item.overallStatus === "findings_detected" ? "Hallazgo sugerido" : "Sin hallazgo"}
            </span>
          </div>
          <p class="feed-title">${escapeHtml(item.file.originalName)}</p>
          <div class="feed-meta-grid">
            <span class="feed-meta-chip">Lado: ${item.affectedSides.length ? escapeHtml(item.affectedSides.join(", ")) : "N/A"}</span>
            <span class="feed-meta-chip">Usuario: ${escapeHtml(item.actor.username)}</span>
          </div>
        </article>
      `
    )
    .join("");
}

function renderAudit(items) {
  if (!items.length) {
    elements.auditList.innerHTML = '<p class="empty-copy">Sin eventos recientes.</p>';
    return;
  }

  elements.auditList.innerHTML = items
    .map((item) => {
      const details = Object.entries(item.details || {})
        .map(([key, value]) => `${escapeHtml(key)}: ${escapeHtml(value)}`)
        .join(" | ") || "Sin detalle adicional.";

      return `
        <article class="feed-item">
          <div class="feed-item-head">
            <p class="feed-date">${formatDate(item.timestamp)}</p>
            <span class="badge audit">${escapeHtml(item.eventType)}</span>
          </div>
          <p class="feed-title">${escapeHtml(item.actor)}</p>
          <p class="feed-meta">${details}</p>
        </article>
      `;
    })
    .join("");
}

function updateNavState(view) {
  elements.navLinks.forEach((link) => {
    const active = link.dataset.view === view;
    link.classList.toggle("is-active", active);
    link.setAttribute("aria-current", active ? "page" : "false");
  });
}

function navigateTo(view) {
  state.activeView = view;
  elements.viewPages.forEach((page) => {
    const shouldShow = page.dataset.view === view;
    page.classList.toggle("hidden", !shouldShow);
  });
  updateNavState(view);
}

async function refreshHistory() {
  if (!state.user) {
    return;
  }

  const payload = await apiFetch("/api/analysis/history?limit=20");
  state.historyItems = payload.items || [];
  renderHistory(state.historyItems);
}

async function refreshAudit() {
  if (!state.user || state.user.role !== "admin") {
    elements.auditCard.classList.add("hidden");
    return;
  }

  elements.auditCard.classList.remove("hidden");
  const payload = await apiFetch("/api/admin/audit?limit=20");
  renderAudit(payload.items || []);
}

async function refreshModelInfo() {
  const payload = await apiFetch("/api/model");
  state.model = payload.model;
  elements.modelBadge.textContent = `${payload.model.modelFamily} ${payload.model.modelVersion}`;
  elements.thresholdBadge.textContent = `Confianza >= ${payload.model.confidenceThreshold}`;
}

function setAuthenticatedView() {
  const loggedIn = Boolean(state.user);
  elements.appShell.classList.toggle("login-mode", !loggedIn);
  elements.authCard.classList.toggle("hidden", loggedIn);
  elements.dashboard.classList.toggle("hidden", !loggedIn);
  elements.logoutButton.classList.toggle("hidden", !loggedIn);
  elements.sessionRoleLabel.textContent = loggedIn ? roleName(state.user.role) : "No autenticado";
  elements.roleGuidance.textContent = roleGuidance(state.user?.role);
  setSystemState(loggedIn ? "Sesión activa" : "Esperando operación", loggedIn ? "success" : "neutral");
  if (loggedIn) {
    navigateTo(state.activeView || "home");
  } else {
    navigateTo("home");
  }
  setAuthFeedback("");
}

async function initializeSession() {
  try {
    const payload = await apiFetch("/api/auth/me");
    state.user = payload.user;
    setAuthenticatedView();
    await refreshModelInfo();
    await refreshHistory();
    await refreshAudit();
  } catch (_error) {
    state.user = null;
    setAuthenticatedView();
    state.analysis = null;
    state.selectedFile = null;
    clearCanvas();
    renderResult();
  }
}

elements.navLinks.forEach((link) => {
  link.addEventListener("click", () => {
    if (!state.user) {
      return;
    }
    navigateTo(link.dataset.view);
  });
});

elements.quickNavButtons.forEach((button) => {
  button.addEventListener("click", () => {
    if (!state.user) {
      return;
    }
    navigateTo(button.dataset.goView);
  });
});

elements.loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  setAuthFeedback("");

  try {
    const payload = await apiFetch("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({
        username: document.getElementById("username").value,
        password: document.getElementById("password").value
      })
    });

    state.user = payload.user;
    state.activeView = "home";
    setAuthenticatedView();
    await refreshModelInfo();
    await refreshHistory();
    await refreshAudit();
    setStatus(
      "Sesión iniciada. Puede comenzar el flujo de análisis.",
      "neutral",
      "Use la navegación superior para avanzar entre secciones."
    );
    document.getElementById("password").value = "";
  } catch (error) {
    setAuthFeedback(error.message, "error");
    setStatus(error.message, "error", "Verifique sus credenciales y vuelva a intentar.");
  }
});

elements.logoutButton.addEventListener("click", async () => {
  try {
    await apiFetch("/api/auth/logout", { method: "POST" });
  } catch (_error) {
  }

  state.user = null;
  state.analysis = null;
  state.selectedFile = null;
  state.activeView = "home";
  if (state.imageUrl) {
    URL.revokeObjectURL(state.imageUrl);
  }
  state.imageUrl = null;
  elements.imageInput.value = "";
  elements.selectedFileLabel.textContent = "Ningún archivo seleccionado.";
  setAuthenticatedView();
  renderResult();
  renderHistory([]);
  renderAudit([]);
  clearCanvas();
});

elements.imageInput.addEventListener("change", async (event) => {
  const [file] = event.target.files;
  state.selectedFile = file || null;

  if (!file) {
    elements.selectedFileLabel.textContent = "Ningún archivo seleccionado.";
    if (state.imageUrl) {
      URL.revokeObjectURL(state.imageUrl);
      state.imageUrl = null;
    }
    clearCanvas();
    return;
  }

  const extension = file.name.split(".").pop()?.toLowerCase() || "";
  if (!ALLOWED_EXTENSIONS.has(extension)) {
    state.selectedFile = null;
    elements.imageInput.value = "";
    elements.selectedFileLabel.textContent = "Ningún archivo seleccionado.";
    setStatus(
      "Formato no permitido. Solo se aceptan archivos .jpg, .jpeg o .png.",
      "error",
      "Verifique el archivo y vuelva a intentar."
    );
    clearCanvas();
    return;
  }

  elements.selectedFileLabel.textContent = `Archivo seleccionado: ${file.name}`;

  if (state.imageUrl) {
    URL.revokeObjectURL(state.imageUrl);
  }

  state.imageUrl = URL.createObjectURL(file);
  await renderImageWithDetections();
  setStatus(
    "Imagen cargada localmente. Lista para análisis.",
    "neutral",
    "Ejecute el análisis para generar resultados."
  );
});

elements.analysisForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  if (!state.selectedFile) {
    setStatus("Seleccione una imagen antes de ejecutar el análisis.", "error");
    return;
  }

  const form = new FormData();
  form.append("image", state.selectedFile);

  try {
    setAnalyzing(true);
    setStatus(
      "Procesando imagen en entorno local...",
      "processing",
      "Espere mientras se ejecuta la inferencia local."
    );
    const payload = await apiFetch("/api/analysis", {
      method: "POST",
      body: form
    });
    state.analysis = payload.analysis;
    renderResult();
    await renderImageWithDetections();
    await refreshHistory();
    await refreshAudit();
    navigateTo("results");
  } catch (error) {
    setStatus(error.message, "error", "Revise el archivo y vuelva a intentar.");
  } finally {
    setAnalyzing(false);
  }
});

navigateTo("home");
clearCanvas();
renderResult();
initializeSession();
