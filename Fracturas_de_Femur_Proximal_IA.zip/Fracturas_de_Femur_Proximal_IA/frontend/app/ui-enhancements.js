(() => {
  const dropzone = document.getElementById("upload-dropzone");
  const imageInput = document.getElementById("image-input");

  if (!dropzone || !imageInput) {
    return;
  }

  const activate = () => dropzone.classList.add("drag-over");
  const deactivate = () => dropzone.classList.remove("drag-over");

  ["dragenter", "dragover"].forEach((eventName) => {
    dropzone.addEventListener(eventName, (event) => {
      event.preventDefault();
      activate();
    });
  });

  ["dragleave", "dragend", "drop"].forEach((eventName) => {
    dropzone.addEventListener(eventName, (event) => {
      event.preventDefault();
      deactivate();
    });
  });

  dropzone.addEventListener("drop", (event) => {
    const files = event.dataTransfer?.files;
    if (!files || files.length === 0) {
      return;
    }

    imageInput.files = files;
    imageInput.dispatchEvent(new Event("change", { bubbles: true }));
  });
})();
